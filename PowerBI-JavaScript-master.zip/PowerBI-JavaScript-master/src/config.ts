// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

/** @ignore *//** */
const config = {
  version: '2.22.2',
  type: 'js'
};

export default config;
